#
# Terraform Environment Variables
#
export TF_VAR_tenancy_ocid="<tenancy ocid>"
export TF_VAR_user_ocid="<user ocid>"
export TF_VAR_fingerprint="<fingerprint>"
export TF_VAR_private_key_path="<Private key pem file name with path>" # example C:\\Users\\OCI\\my_private.pem"
export TF_VAR_region="uk-london-1"

#
# Confidential Variables
#
export TF_VAR_first_subscriber_clients_name="kuldeep_cidxxx"
export TF_VAR_first_subscriber_clients_token="kuldeep_cid_tokenxxx"